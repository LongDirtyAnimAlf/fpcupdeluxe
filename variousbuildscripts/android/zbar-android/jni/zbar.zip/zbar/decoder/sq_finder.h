#ifndef _DECODER_SQ_FINDER_H_
#define _DECODER_SQ_FINDER_H_

/* SQ Code symbol finder state */
typedef struct sq_finder_s {
    unsigned config;
} sq_finder_t;

#endif
